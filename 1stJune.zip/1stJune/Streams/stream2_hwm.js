var fs=require('fs')
var myReadStream=fs.createReadStream(__dirname+'/demo.txt',{
    encoding:'utf8',
    highWaterMark:30,
    start:0,
    end:300
})

myReadStream.on('data',function(chunk){
console.log("*********** new chunk received***********")
console.log(chunk)
})
