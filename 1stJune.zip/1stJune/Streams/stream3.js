const fs=require('fs')
const file=fs.createWriteStream('demo2.txt')
file.write("hello")
file.end()
