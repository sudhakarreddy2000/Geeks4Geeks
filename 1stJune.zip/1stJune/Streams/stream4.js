var fs=require('fs')
var myReadStream=fs.createReadStream(__dirname+'/demo.txt','utf8')
var myWriteStream=fs.createWriteStream(__dirname+'/demo1.txt')
myReadStream.on('data',function(chunk){
    console.log("new chunk received")
    myWriteStream.write(chunk)
    
})
