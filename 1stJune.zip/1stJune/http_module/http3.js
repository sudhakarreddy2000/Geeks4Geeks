const fs=require('fs')
const http=require('http')
http.createServer((req,res)=>{
        res.writeHead(200,{
        //'Content-type':'text/plain'
        'Content-type':'text/html'
    })
    fs.readFile('web.html','utf8',(err,data)=>{
        res.write(data)
        res.end()
    })
}).listen(3000,()=>console.log("server started..."))