const fs=require('fs')
const http=require('http')
http.createServer((req,res)=>{
    fs.readFile('demo.txt','utf8',(err,data)=>{
        res.write(data)
        res.end()
    })
}).listen(3000,()=>console.log("server started..."))