const http=require('http')
http.createServer((req,res)=>{
    res.write("message from server side")
    res.end()
}).listen(3000,()=>console.log("Server started.."))