const fs=require('fs')
fs.unlink('demo.text',(err)=>{
if(!err){
    console.log("File deleted..")
}else{
    console.log("some error")
}
})