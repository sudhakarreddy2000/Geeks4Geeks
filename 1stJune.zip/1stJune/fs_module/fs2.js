const fs=require('fs')
let data="Some message"
fs.writeFile("demo1.txt",data,(err)=>{
    if(!err){
        console.log("File created..")
    }else{
        console.log(err)
    }
})