const fs=require('fs')
console.log("Program Started..")
fs.readFile('demo1.txt','utf8',(err,data)=>{
    if(!err){
        console.log(data)
    }
})

console.log("program ended..")