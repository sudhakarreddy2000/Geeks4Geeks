const fs=require('fs')
fs.mkdir('demodir',(err)=>{
if(!err){
    console.log("directory created..")
}else{
    console.log("some error")
}
})