const fs=require('fs')
console.log("Program Started..")
const data=fs.readFileSync('demo1.txt')
console.log(data.toString())

console.log("Program Ended...")