const EventEmitter=require('events')
const event=new EventEmitter();

event.on('test',()=>{
    console.log("event fired..")
})

event.emit('test')