const express=require('express')
const app=express()
const validator=(req,res,next)=>{
    if(!req.query.age){
        res.send("Age is required..")
    }else if(req.query.age<18){
        res.send("Age should be above 18")
    }else{
        next()
    }
}
app.use(validator)
app.get('/',(req,res)=>{
    res.send("Welcome to Express")
})
app.get('/about', (req,res)=>{
    res.send("About us content here")
})

app.listen(3000,()=>console.log("Server started.."))