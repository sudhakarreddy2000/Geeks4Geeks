const express=require('express')
const app=express()

app.get('/',(req,res)=>{
    res.send("Welcome to Express")
})
app.get('/about', (req,res)=>{
    res.send("About us content here")
})
app.get('/json',(req,res)=>{
    res.json({people:[{name:"Sudhakar"}]});
})
app.listen(3000,()=>console.log("Server started.."))