const express=require('express')
const app=express()
app.set('view engine', 'ejs')

app.get('/',(req,res)=>{
    res.send("Home page")
})
app.get('/page',(req,res)=>{
    const person={
        name:'Sudhakar',
        place:'Hyderabad',
        age:22,
        email:'ajay@gmail.com'
    }
    res.render('index1',{data:person})
})
app.listen(3000,()=>console.log("Server started.."))