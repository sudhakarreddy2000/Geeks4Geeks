const express=require('express')
const app=express();
const mongoose=require('mongoose')

app.set('view engine', 'ejs')

app.use(express.json()); 
app.use(express.urlencoded())

const connectDB=async()=>{
    try{
        await mongoose.connect("mongodb://127.0.0.1:27017/g4g")
        console.log("Connected to database")
    }catch(err){
        console.log("some error")
    }
}
connectDB()
const schema=mongoose.Schema({
    name:String,
    place:String,
    age:Number
})

const myModel=mongoose.model("users",schema)

app.get('/',(req,res)=>{
    res.render('insert')
})

app.post('/insert',(req,res)=>{
    var user=new myModel({
        name:req.body.name,
        place:req.body.place,
        age:req.body.age
    })
    user.save()
    .then(()=>res.redirect('/show'))
    .catch((err)=>console.log("Some error"))
})

app.get('/show',(req, res)=>{
    myModel.find({})
    .then((result)=>res.render('show',{users:result}))
    .catch((err)=>console.log(err))
})

app.get('/delete/:id',async(req,res)=>{
     await myModel.findByIdAndDelete(req.params.id);
    res.redirect('/show')
})
app.get('/edit/:id',async function(req,res){
	const result=await myModel.findById(req.params.id)
		res.render('edit',{users:result});
	})

app.post('/update/:id',async function(req,res){
    await myModel.findByIdAndUpdate(req.params.id,req.body);
    res.redirect('/show')
    })
app.listen(3000, console.log("Server started.."))