const express=require('express')
const app=express();

app.get('/user/:id',(req,res)=>{
    res.send("Hello "+req.params.id)
})
app.listen(3000,()=>console.log("Server strarted"))