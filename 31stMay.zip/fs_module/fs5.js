const fs=require('fs')
fs.rename('demo.txt','demo100.txt',(err)=>{
if(!err){
    console.log("File renamed..")
}else{
    console.log("some error")
}
})