const fs=require('fs')
let data=" Today is Saturday"
fs.appendFile(__dirname+"/demo.txt",data,(err)=>{
    if(!err){
        console.log('File updated..')
    }else{
        console.log("some error")
    }
})