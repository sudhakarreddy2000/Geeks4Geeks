const fs=require('fs')
fs.rmdir('demodir',(err)=>{
if(!err){
    console.log("directory deleted..")
}else{
    console.log("some error")
}
})