import React, { useState, useMemo } from 'react'
import Data from './city.json'
export default function App() {
   const [state, setState]=useState(Data)
   const [search, setSearch]=useState()
const handler=(e)=>{
  setState(e.target.value)
}
   return (
    <>
<input type="text" placeholder='search ....' value={search}
    onChange={(e)=>setSearch(e.target.value)}/>
{state.filter(item=>item.name.includes(search))
.map(item=><li>{item.name}</li>)}
   </>
  )
}