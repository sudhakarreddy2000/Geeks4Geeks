import React from 'react'
import { useState, useEffect } from 'react'
export default function App() {
    const[state, setState]=useState([])

    useEffect(()=>{
fetch('https://randomuser.me/api/?results=50')
      .then(response => response.json())
      //.then(json => console.log(json.results))
      .then(json => setState(json.results))
    },[])

  return (
    <>
    <h1>hooks-useState() hook</h1>
 {state.map((item)=><li>
  {item.name.first}</li>)}
    </>
  )
}