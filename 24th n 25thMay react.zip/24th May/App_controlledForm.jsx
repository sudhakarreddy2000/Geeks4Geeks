import React, { useState, useMemo } from 'react'
export default function App() {
 const [state, setState]=useState()
 const handler=(e)=>{
  //setState("React")
  setState(e.target.value)
 }
   return (
    <>
  <input type="text" placeholder='name' value={state} 
  onChange={handler}/>
   </>
  )
}