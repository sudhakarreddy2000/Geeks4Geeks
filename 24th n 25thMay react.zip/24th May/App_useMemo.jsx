import React, { useState, useMemo } from 'react'
export default function App() {
  const [add,setAdd]=useState(0)
  const [del, setDel]=useState(100)
  const addition=()=>{
    setAdd(add+1)
  }
  const deletion=()=>{
    setDel(del-1)
  }
//   const multiplication=()=>{
//     console.log("message")
//     return add*5 
//  }
  const multiplication=useMemo(function multiply(){
    console.log("g4g")
    return add*10
  },[add])

   return (
    <>
    <h1>useMemo</h1>
    {multiplication}
    <h3>{add}</h3>
    <button onClick={addition}>Add</button>
    <br/>
    <h3>{del}</h3>
    <button onClick={deletion}>Del</button>
    </>
  )
}