import React from 'react'
import {BrowserRouter, Routes, Route} from 'react-router-dom'
export default function App() {
   return (
    <>
<h1>Single Page Application</h1>
<BrowserRouter>
<Routes>
   <Route path='/' element={<h1>Welcome to Routing</h1>}/>
   <Route path='/about' element={<h2>About us</h2>}/>
   <Route path='/courses' element={<h2>Courses</h2>}/>
   <Route path='/contact' element={<h2>Contact</h2>}/>
</Routes>
</BrowserRouter>
   </>
  )
}