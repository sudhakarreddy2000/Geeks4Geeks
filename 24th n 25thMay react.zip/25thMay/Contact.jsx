import React from 'react'

export default function Contact() {
  return (
    <div>
      <h3>Contact Us</h3>
    </div>
  )
}
