import { useState } from "react"
function Add(){
    const [count, setCount]=useState(0)
    return(
      <>
      <h3>{count}</h3>
  <button onClick={()=>setCount(count+1)}>update</button>
      </>
    )
  }
  export default Add