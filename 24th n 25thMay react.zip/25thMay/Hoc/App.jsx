import React from 'react'
import Add from './Add'
import Del from './Del'
import Hoc from './Hoc'
export default function App() {
   return (
    <>
<h1>HOC</h1>
<Hoc cmp={Add}/>
<Hoc cmp={Del}/>
   </>
  )
}