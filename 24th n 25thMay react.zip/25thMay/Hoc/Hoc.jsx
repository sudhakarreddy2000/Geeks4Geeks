import React from 'react'
const clr={
    color:'white',
    background:'black'
    
}
export default function Hoc(props) {
  return (
    
<h3 style={clr}><props.cmp/></h3>
   
  )
}
