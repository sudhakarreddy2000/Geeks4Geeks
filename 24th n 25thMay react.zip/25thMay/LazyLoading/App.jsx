import React, { Suspense } from "react";

const AboutComponent = React.lazy(() => import('./AboutComponent'));
const App = () => (
    <div>
      <Suspense fallback = { 
<div> Please Wait... </div> } >
      <AboutComponent />
      </Suspense>
    </div>
);
export default App
