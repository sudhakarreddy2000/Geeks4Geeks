import React from 'react'

export default function AboutComponent() {
  return (
    <div>
      <h1>AboutComponent</h1>
      <h1>AboutComponent</h1>
      <h1>AboutComponent</h1>
      <h1>AboutComponent</h1>
      <h1>AboutComponent</h1>

      <h1>AboutComponent</h1>
    </div>
  )
}
