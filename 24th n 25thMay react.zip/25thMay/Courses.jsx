import React from 'react'

export default function Courses() {
  return (
    <div>
      <h2>Courses</h2>
      <p>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sunt temporibus ab corporis? Eius illo eos dolorum dolores ratione sapiente molestias quisquam quam perspiciatis consequuntur amet ab aspernatur, vel est qui mollitia omnis neque hic quae a cum consectetur facilis saepe. Excepturi accusamus officiis iure provident debitis quam nam sed quaerat unde aliquam fugiat pariatur dolorum eum laborum cumque mollitia obcaecati ullam reprehenderit aut blanditiis consectetur odit, repudiandae autem! Perspiciatis illo molestiae id at odit exercitationem impedit praesentium provident magnam tenetur totam, possimus nulla, ullam, debitis corrupti alias? Quisquam distinctio accusantium aperiam tempore debitis aliquam veritatis corporis qui incidunt. Alias, nostrum!
      </p>
    </div>
  )
}
