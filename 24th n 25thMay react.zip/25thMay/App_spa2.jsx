import React from 'react'
import {BrowserRouter, Routes, Route, Link} from 'react-router-dom'
import About from './About'
import Courses from './Courses'
import Contact from './Contact'
export default function App() {
   return (
    <>
<h1>Single Page Application</h1>
<BrowserRouter>
<Link to="/">Home</Link>
<Link to="/about">About</Link>
<Link to="/courses">Courses</Link>
<Link to="/contact">Contact</Link>
<Routes>
   <Route path='/' element={<h1>Welcome to Routing</h1>}/>
   <Route path='/about' element={<About/>}/>
   <Route path='/courses' element={<Courses/>}/>
   <Route path='/contact' element={<Contact/>}/>
</Routes>
</BrowserRouter>
   </>
  )
}