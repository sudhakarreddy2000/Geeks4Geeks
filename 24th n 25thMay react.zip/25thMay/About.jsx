import React from 'react'
import pic from './scene1.jpeg'
export default function About() {
  return (
    <>
      <h1>About Us</h1>
      <p>
        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Eius, nam minima hic exercitationem velit vero, impedit fugit perspiciatis iusto quod ut id aspernatur alias officiis at maxime? Distinctio totam maxime iste, nisi animi earum provident, doloremque dolores, aut maiores veritatis veniam natus quisquam excepturi praesentium ipsa et non enim cumque pariatur! Necessitatibus totam qui commodi blanditiis accusantium ratione fugiat ullam sequi deleniti sed porro eaque perspiciatis, eligendi quos, aliquam soluta magni minus veniam, ipsum eos asperiores atque! Eveniet, sit nulla. Sed aperiam odio ex debitis illo. Optio exercitationem explicabo vel saepe quisquam laborum velit hic aperiam. Adipisci maiores magnam mollitia.
      </p>
      <img src={pic}/>
    </>
  )
}
