import {createRoot} from 'react-dom/client'
const obj=new Date();
const h=obj.getHours()
let result;
let clr={ }
if(h<12){
    result="Good Morning"
    clr.color='Green'
}else if(h>=12 && h<=17){
    result="Good Afternoon"
    clr.color='red'
}else{
    result="Good Evening"
    clr.color='orange'
}
createRoot(document.getElementById('root')).render(
    <>
    <h1>Welcome to react</h1>
   <h2 style={clr}>{result}</h2>
    </>
)