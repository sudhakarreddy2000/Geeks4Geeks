let a=100
let b=200
let c=300
let students=['Anil','Sunil','Kapil']
let obj={
    name:'Vijay',
    age:22,
    place:'Hyderabad'
}
function demo(){
    return 'Hello React'
}
export default a
export {b,c,students,obj,demo}