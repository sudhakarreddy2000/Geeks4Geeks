import {createRoot} from 'react-dom/client'
let students=['Rohan','Sohan','Mohan','Rooth','Vidya']
let obj={
    fname:'Suresh',
    lname:'Kumar',
    age:22,
    place:'Delhi'
}
createRoot(document.getElementById('root')).render(
    <>
    <h1>Welcome to react</h1>
  <h2>{students}</h2>
  <h2>{students[0]}</h2>
  <h2>{obj.fname}</h2>
    </>
)