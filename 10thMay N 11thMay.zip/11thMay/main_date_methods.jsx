import {createRoot} from 'react-dom/client'
const obj=new Date();
let h=obj.getHours();
let m=obj.getMinutes();
let s=obj.getSeconds();
let time=obj.toLocaleTimeString();
let date=obj.toLocaleDateString();
createRoot(document.getElementById('root')).render(
    <>
    <h1>Welcome to react</h1>
    <h2>{Date()}</h2>
    <h2>{h}:{m}:{s}</h2>
    <h2>{time}</h2>
    <h2>{date}</h2>
    </>
)