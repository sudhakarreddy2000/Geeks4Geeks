import {createRoot} from 'react-dom/client'
let uid=prompt("Enter user id here")
let result;
if(uid=="react"){
    result="matched"
}else{
    result="not matched"
}
createRoot(document.getElementById('root')).render(
    <>
    <h1>Welcome to react</h1>
    <h2>{result}</h2>
    </>
)