import {createRoot} from 'react-dom/client'

createRoot(document.getElementById('root')).render(
    <>
    <h1 style={{color:'red'}}>Welcome to react</h1>
   
    </>
)