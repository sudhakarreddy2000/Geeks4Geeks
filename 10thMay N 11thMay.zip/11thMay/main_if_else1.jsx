import {createRoot} from 'react-dom/client'
let marks=prompt("enter marks here")
let result;
if(marks<=40){
    result="Failed"
}else{
    result="Passed"
}
createRoot(document.getElementById('root')).render(
    <>
    <h1>Welcome to react</h1>
    <h2>{result}</h2>
    </>
)