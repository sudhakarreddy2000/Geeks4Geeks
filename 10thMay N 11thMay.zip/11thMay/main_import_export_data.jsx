import {createRoot} from 'react-dom/client'
import a, {b,c, students,obj,demo} from './data.jsx'
createRoot(document.getElementById('root')).render(
    <>
<h1>Welcome to react</h1>
<h3>{a}</h3>
<h3>{b}</h3>
<h3>{c}</h3>
<h3>{students}</h3>
<h3>{obj.name}</h3>
<h3>{demo()}</h3>
    </>
)