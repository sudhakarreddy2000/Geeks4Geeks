import {createRoot} from 'react-dom/client'
import './style.css'
createRoot(document.getElementById('root')).render(
    <>
<h1 className='txt'>Welcome to react</h1>
<h1>Welcome to react</h1>
<h1>Welcome to react</h1>
<h1>Welcome to react</h1>
<h1>Welcome to react</h1>
<h1>Welcome to react</h1>
<h1>Welcome to react</h1>
    </>
)