import {createRoot} from 'react-dom/client'
var uid="Geeks for Geeks"
var num1=30
var num2=40
createRoot(document.getElementById('root')).render(
    <>
    <h1>Welcome to react</h1>
    <h3>Welcome to {uid} </h3>
    <h3>{num1+num2}</h3>
    </>
)