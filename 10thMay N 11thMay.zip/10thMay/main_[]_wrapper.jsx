import {createRoot} from 'react-dom/client'

createRoot(document.getElementById('root')).render(
    [
    <h1>Welcome to react</h1>,
    <h2>React is easy</h2>
    ]
)