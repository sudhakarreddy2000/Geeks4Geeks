import {createRoot} from 'react-dom/client'
var num1=prompt("enter number1")
var num2=prompt("enter number2")
createRoot(document.getElementById('root')).render(
    <>
    <h1>Welcome to react</h1>
    <h2>Total is {Number(num1)+Number(num2)} </h2>
    </>
)