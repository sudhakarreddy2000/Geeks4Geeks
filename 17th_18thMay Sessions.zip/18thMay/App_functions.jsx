import React from 'react'
export default function App() {
    // function myFunction(){
    //     alert("Welcome to functions")
    // }
    const myFunction=()=>{
        alert("Welcome to Arrow functions")
    }
  return (
    <>
      <h1>App component</h1>
      {myFunction()}
    </>
  )
}
