import React from 'react'
import { useState } from 'react'
export default function App() {
    let uid="Geeks4Geeks"
const [state, setState]=useState(['Anil','Sunil','Mohan','Preethy'])
const [name, setName]=useState(uid)
  return (
    <>
      <h1>hooks-useState() hook</h1>
     <h2>{state}</h2>
     <h2>{state[1]}</h2>
     <h2>{name}</h2>
    </>
  )
}
