import React from 'react'
import { useState } from 'react'
export default function App() {
    const [state, setState]=useState("Geeks For Geeks")
  return (
    <>
      <h1>hooks-useState() hook</h1>
        <h2>{state}</h2>
    </>
  )
}
