import {createRoot} from 'react-dom/client'
import App from './App'
createRoot(document.getElementById('root')).render(
    <>
    <h1>react</h1>
  <App/>
    </>
)
