import React from 'react'
export default function App() {
    const myFunction=()=>{
        alert("Welcome to onclick event")
    }
  return (
    <>
      <h1>App component</h1>
      <button onClick={myFunction}>clickme</button>
      <button onMouseOver={myFunction}>mouseOver</button>
      <button onMouseOut={myFunction}>mouseOut</button>
    </>
  )
}
