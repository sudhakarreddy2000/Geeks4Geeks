import React from 'react'
import { useState } from 'react'
export default function App() {
let users=['Ajay','Vijay','Taruna','Deepa','Keerthi']
const [state, setState]=useState(users)
  return (
    <>
    <h1>hooks-useState() hook</h1>
    <ul>
     {state.map((item)=><li>{item}</li>)}
     </ul>

    <table border='1px'>
        <tr>
            <td>Names</td>
        </tr>
        {state.map((item)=><tr><td>{item}</td></tr>)}
    </table>
    </>
  )
}