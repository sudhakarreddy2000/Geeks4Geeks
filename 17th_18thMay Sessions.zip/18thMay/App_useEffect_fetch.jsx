import React from 'react'
import { useState, useEffect } from 'react'
export default function App() {
    const[state, setState]=useState([])

    useEffect(()=>{
fetch('https://jsonplaceholder.typicode.com/todos')
      .then(response => response.json())
      //.then(json => console.log(json))
      .then(json => setState(json))
    },[])

  return (
    <>
    <h1>hooks-useState() hook</h1>
    <ul>
    {state.map((item)=><li>{item.title}</li>)}
    </ul>
    </>
  )
}