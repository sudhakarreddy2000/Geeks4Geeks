import React from 'react'
import { useState } from 'react'
export default function App() {
let nums=[1,2,3,4,5]
const [state, setState]=useState(nums)
  return (
    <>
    <h1>hooks-useState() hook</h1>
     <h2>{state}</h2>
     {state.map((item)=><p>{item}</p>)}

    </>
  )
}
