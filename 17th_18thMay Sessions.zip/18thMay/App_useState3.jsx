import React from 'react'
import { useState } from 'react'
export default function App() {
let uid="Geeks4Geeks"
let users=['Anil','Sunil','Mohan','Preethy']
let person={
    fname:'Vikas',
    place:'Delhi',
    age:22
}
const [state, setState]=useState(users)
const [name, setName]=useState(uid)
const [member, setMember]=useState(person)
  return (
    <>
    <h1>hooks-useState() hook</h1>
     <h2>{state}</h2>
     <h2>{state[1]}</h2>
     <h2>{name}</h2>
     <h2>{member.fname}</h2>
    </>
  )
}
