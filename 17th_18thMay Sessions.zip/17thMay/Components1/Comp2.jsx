function Comp2(){
    return(
        <>
        <h2>Function Component</h2>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quo porro magni beatae doloremque aspernatur fuga cupiditate cum saepe nemo sunt ducimus reprehenderit optio veritatis itaque magnam accusantium atque velit tenetur a hic deleniti qui, enim nisi! Cum, est sequi sint quis assumenda qui eveniet itaque ducimus laborum error harum repellendus officiis quod veniam minus, fuga animi nostrum soluta et doloribus magnam. Molestiae, nobis eos eius minus suscipit sequi dignissimos expedita voluptate aliquid. Ea ex inventore laboriosam saepe sapiente minus quos maiores doloremque dolores architecto! Dolore, labore! Sapiente quo aliquid debitis, tempora voluptatem nisi, beatae fuga sequi maxime, ab ex ea!
        </p>
        </>
    )
}
export default Comp2