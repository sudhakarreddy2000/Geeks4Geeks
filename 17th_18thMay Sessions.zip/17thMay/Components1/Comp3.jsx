const Comp3=()=>{
    return(
        <>
        <h2> examples of component</h2>
        <p>
            Lorem ipsum dolor sit, amet consectetur adipisicing elit. Molestias est perferendis neque impedit perspiciatis harum corporis accusantium nam ipsa tenetur pariatur ipsam non exercitationem voluptatum eaque, dolores ratione nesciunt illum quibusdam aliquam magni fugit odit magnam amet! In atque blanditiis soluta nostrum quo ut consectetur necessitatibus, excepturi odio qui et non modi voluptas minus cupiditate fugit expedita pariatur, corrupti vero molestias consequuntur quod quisquam, eaque mollitia. Tenetur ipsa exercitationem corrupti. Est molestiae animi amet quos commodi, possimus quod veniam. Voluptate, inventore? Et, expedita. Blanditiis, possimus quas. Sapiente sunt, voluptatibus delectus eos voluptatum laboriosam voluptates amet aliquid qui nemo saepe blanditiis!
        </p>
        </>
    )
}
export default Comp3