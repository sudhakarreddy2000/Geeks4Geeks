function Comp1(){
    return(
        <>
        <h1>React components</h1>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Totam necessitatibus eligendi ipsum odit numquam itaque, expedita repudiandae fugit modi architecto ipsa, vero impedit dignissimos omnis aliquam, neque facere sunt excepturi inventore voluptates quas iusto praesentium earum qui. Nesciunt cupiditate, molestias ex similique perspiciatis quae ullam, impedit recusandae in aperiam, dolore veniam labore dicta laudantium ea commodi molestiae libero neque aspernatur eveniet vel et harum mollitia! Modi sed, voluptatibus mollitia voluptatum accusamus placeat rerum exercitationem reiciendis libero, sapiente provident, debitis neque obcaecati. Non odio culpa delectus quos, maiores ea esse suscipit consectetur iste eveniet inventore eaque eum consequatur explicabo illum minus aliquam temporibus. Magnam amet fuga officiis commodi sed iusto sint quia molestias iste, nam ratione est illum eveniet sit modi quis corporis temporibus maiores repudiandae? Impedit reprehenderit perspiciatis, qui quia nostrum accusamus cupiditate aliquid sequi magni non a laboriosam similique iusto, possimus officiis corrupti tenetur corporis eaque. Quam dolor ad, doloribus sequi itaque eum incidunt dignissimos aliquam fuga consequatur dicta animi, tenetur corrupti praesentium at, esse autem. Itaque laudantium sint corporis ab aliquam perferendis repellat dolorem, porro illo architecto dolores cum unde esse cumque facilis, voluptatum odit fugiat tenetur sed expedita? Magnam sed ullam odio necessitatibus, sint eos eum culpa?
        </p>
        </>
    )
}
export default Comp1