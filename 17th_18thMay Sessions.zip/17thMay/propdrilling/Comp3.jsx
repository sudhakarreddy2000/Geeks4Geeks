function Comp3({data}){
    return(
        <>
        <h2>Component 3</h2>
        <h2>{data}</h2>
        </>
    )
}
export default Comp3