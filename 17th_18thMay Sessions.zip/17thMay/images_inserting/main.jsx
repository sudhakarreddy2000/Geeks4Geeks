import {createRoot} from 'react-dom/client'
import pic from './flower.jpeg'
createRoot(document.getElementById('root')).render(
    <>
    <h2>Inserting images</h2>
    <img src={pic}/>
    <br/>
    <img src="vite.svg"/>
    </>
)