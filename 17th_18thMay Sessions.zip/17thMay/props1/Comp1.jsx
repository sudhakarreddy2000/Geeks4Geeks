function Comp1(props){
    return(
        <>
        <h2>Comp1</h2>
        <h2>{props.data}</h2>
             </>
    )
}
export default Comp1