import {createRoot} from 'react-dom/client'
import Comp1 from './Comp1'
var uid="React"
createRoot(document.getElementById('root')).render(
    <>
    <Comp1 data={uid}/>
    </>
)
