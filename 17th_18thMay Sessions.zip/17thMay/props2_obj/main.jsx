import {createRoot} from 'react-dom/client'
import Comp1 from './Comp1'
import pic from './scene1.jpeg'

const person={
    name:'Vijay',
    place:'Secunderabad',
    email:'vijay@gmail.com',
    picture:pic,
    picture2:'https://static.vecteezy.com/system/resources/thumbnails/057/949/647/small/mountain-landscape-with-majestic-sunset-over-clouds-for-nature-lovers-and-travel-enthusiasts-photo.jpg'
}
createRoot(document.getElementById('root')).render(
    <>
    <Comp1 x={person}/>
    </>
)
