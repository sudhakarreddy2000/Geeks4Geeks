function Comp1(props){
    return(
        <>
        <h2>Comp1</h2>
        <h2>Name is {props.x.name}</h2>
        <h2>Place is {props.x.place}</h2>
        <h2>Age is {props.x.email} </h2>
        <img src={props.x.picture}/>
        <br/>
        <img src={props.x.picture2}/>
             </>
    )
}
export default Comp1